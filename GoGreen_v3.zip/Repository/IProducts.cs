﻿using GoGreen.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGreen.Repository
{
    public interface IProducts
    {
        List<ProductModel> GetAllProducts();
        List<Product> GetProductsFromCache();
        List<ProductModel> GetCategoryWiseProducts(string categoryname);
        Product GetProductById(int id);
        Product_Price GetPriceForPackAndProduct(int id, string pack);

    }
    public interface ICustomers
    {
        bool AddCustomerDetails(Customer customer);
        int GetCount();
        Customer GetCustomerId(string Name);
        void UpdateCustomer(Customer customer);


    }
}
