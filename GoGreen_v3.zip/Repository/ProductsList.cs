﻿using GoGreen.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Caching;
using System.Web.Mvc;

namespace GoGreen.Repository
{
    public class ProductsList : IProducts
    {
        private GoGreenEntities _productscontext = new GoGreenEntities();

        public ProductsList()
        {
           
        }

       
        public List<ProductModel> GetAllProducts()
        {
            List<ProductModel> products = new List<ProductModel>();

           var data = _productscontext.Products.ToList();
            // Create the cache for products and products_price.
            if (HttpRuntime.Cache["products_price"] == null)
               
                HttpRuntime.Cache.Insert("products_price", _productscontext.Product_Price.ToList(), null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(80));
            if (HttpRuntime.Cache["products"] == null)
            {
                HttpRuntime.Cache.Insert("products", data, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(80));
            }

            foreach (var singleprod in data)
            {
                ProductModel product = new ProductModel();

                product.ID = singleprod.ProductId;
                product.Name = singleprod.ProductName;
                product.ImageUrl = singleprod.ImageUrl;
                product.ProductCategory = singleprod.Category;

                var packlist = new List<SelectListItem>();
                
                foreach (var element in singleprod.Product_Price)
                {
                    packlist.Add(new SelectListItem
                    {
                        Value = element.Pack.ToString(),
                        Text = element.Pack
                    });

                }
                product.ProductPacks = packlist;
                foreach (var prod_pr in singleprod.Product_Price)
                {
                    if (prod_pr.Description == "One")
                    {
                        product.ProductPrice = prod_pr.Price;
                        break;
                    }
                }
                products.Add(product);


                
                

            }
            return (products.ToList());

        }

        public Product_Price GetPriceForPackAndProduct(int id, string pack)
        {
            var prices = HttpRuntime.Cache.Get("products_price") as List<Product_Price>;
            return prices.Where(m => m.ProductId == id && m.Pack.Trim() == pack).FirstOrDefault();
            

        }

        public Product GetProductById(int id)
        {
           var products = GetProductsFromCache();

            try
            {
                //return _productscontext.Products.Find(id);
                return products.Where(a => a.ProductId == id).FirstOrDefault() ;
            }
            catch (Exception)
            {

                throw;
            }


        }


        public List<Product> GetProductsFromCache()
        {
            return HttpRuntime.Cache.Get("products") as List<Product>;
        }

        public List<ProductModel> GetCategoryWiseProducts(string categoryname)
        {

            List<ProductModel> products = new List<ProductModel>();
           List<Product> data = new List<Product>();

            var cachedata = GetProductsFromCache();
            if (cachedata != null)
                data = cachedata.Where(m => m.Category == categoryname).ToList();
            else
                data = _productscontext.Products.Where(m => m.Category == categoryname).ToList();

            foreach (var singleprod in data)
            {
                ProductModel product = new ProductModel();

                product.ID = singleprod.ProductId;
                product.Name = singleprod.ProductName;
                product.ImageUrl = singleprod.ImageUrl;
                product.ProductCategory = singleprod.Category;

                var packlist = new List<SelectListItem>();
                var pricelist = new List<SelectListItem>();
                foreach (var element in singleprod.Product_Price)
                {
                    packlist.Add(new SelectListItem
                    {
                        Value = element.Pack.ToString(),
                        Text = element.Pack
                    });

                }
                product.ProductPacks = packlist;
                foreach (var prod_pr in singleprod.Product_Price)
                {
                    if (prod_pr.Description == "One")
                    {
                        product.ProductPrice = prod_pr.Price;
                        break;
                    }
                }
                products.Add(product);
            }
            return (products.ToList());
        }



    }

        public class Customers : ICustomers

        {

            GoGreenEntities _customercontext = new GoGreenEntities();

            public bool AddCustomerDetails(Customer customer)
            {
                _customercontext.Customers.Add(customer);
                return _customercontext.SaveChanges() > 0;

            }
            public Customer GetCustomerId(string Name)
            {
                return _customercontext.Customers.Where(x => x.CustomerName.Trim() == Name).FirstOrDefault();

            }


            public void UpdateCustomer(Customer customer)
            {
                _customercontext.Entry(customer).State = System.Data.Entity.EntityState.Modified;
                _customercontext.SaveChanges();

            }

            public int GetCount()
            {
                return _customercontext.Customers.Count();
            }
        }
        public class Orders : IOrders
        {
            GoGreenEntities _orderscontext = new GoGreenEntities();
            public bool AddOrderHeader(OrderHeader orderhead)
            {
                _orderscontext.OrderHeaders.Add(orderhead);
                return _orderscontext.SaveChanges() > 0;

            }

        }

        public interface IOrders
        {
            bool AddOrderHeader(OrderHeader orderhead);




        }
    
}

