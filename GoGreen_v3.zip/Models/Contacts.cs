﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GoGreen.Models
{
    public class Contacts
    {
        
            public string FromName { get; set; }
            public string FromEmail { get; set; }
            public string Message { get; set; }
            public string Subject { get; set; }
            public string PhoneNumber { get; set; }
        }
    
}