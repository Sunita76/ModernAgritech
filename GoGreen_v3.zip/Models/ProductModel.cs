﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GoGreen.Models
{
    public class ProductModel
    {
        
            public int ID { get; set; }
            public string Name { get; set; }
            public string ImageUrl { get; set; }
            public string ProductCategory { get; set; }  //this is the category of the product
           
        public IEnumerable<SelectListItem> ProductPacks { get; set; }
        public double ProductPrice { get; set; }
        


    }

    public class ProductPriceModel
    {
        public string Description { get; set; }
        public string Pack { get; set; }
        [DisplayFormat(DataFormatString = "{0:C0}", ApplyFormatInEditMode = true)]
        public double? PackPrice { get; set; }

    }

    public class CartProductModel
    {

        public int ID { get; set; }
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public string ProductCategory { get; set; }  //this is the category of the product
        public string Pack { get; set; }  
        public double? PriceProduct { get; set; } 

       

    }


}