﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GoGreen.Models
{
    public class CustomerAndOrderViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string State { get; set; }
        public string Address { get; set; }
        public string Town { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public int PinCode { get; set; }
        public bool StoreAddress { get; set; }

        

        public List<ShoppingCartModel> CartItems { get; set; } // the list of cart items.

        public CustomerAndOrderViewModel() { }   
    }
}