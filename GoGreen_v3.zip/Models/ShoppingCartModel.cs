﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GoGreen.Models
{
    public class ShoppingCartModel
    {
        public CartProductModel CartProduct { get; set; }
        public int Quantity { get; set; }
        public double? TotalPrice { get; set; }
    }
}