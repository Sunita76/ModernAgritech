﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GoGreen.Controllers
{
    public class ShoppingController : Controller
    {
        public ActionResult Create()
        {
            return View();
        }

        //[HttpPost]
        //public ActionResult Create(ProductModel model)
        //{
          //  HttpPostedFileBase file = Request.Files["ImageData"];

            //ContentRepository service =

            GoGreenEntities context = new GoGreenEntities();
            // I was not able to access the edmx in the controller,so i closed the solution, opened it again and build again.

            //model.Image = ConvertToBytes(file);
            //var Product = new Product
            //{
            //    ProductName = "BoneMeal",
            //    Description = "This is an organic manure",
            //    Price = 120,
            //    Image = model.Image,

            //};

            //context.Products.Add(Product);
            //context.SaveChanges();
            //return View();



        //}

        //public byte[] ConvertToBytes(HttpPostedFileBase image)
        //{
        //    byte[] imageBytes = null;
        //    BinaryReader reader = new BinaryReader(image.InputStream);
        //    imageBytes = reader.ReadBytes((int)image.ContentLength);
        //    return imageBytes;
        //}
        //public ActionResult About()
        //{
        //    //ViewBag.Message = "Your application description page.";

        //    return View();
        //}

        //public ActionResult Contact()
        //{
        //    ViewBag.Message = "Your contact page.";

        //    return View();
        //}
    }
}
//Order newOrder = new Order();
//newOrder.UserID = User.Identity.GetUserId();
//newOrder.OrderedAt = DateTime.Now;
//newOrder.Status = "Pending";
//newOrder.TotalAmount = boughtProducts.Sum(x => x.Price * productQuantities.Where(productID => productID == x.ID).Count());

//newOrder.OrderItems = new List<OrderItem>();
//newOrder.OrderItems.AddRange(boughtProducts.Select(x => new OrderItem() { ProductID = x.ID, Quantity = productQuantities.Where(productID => productID == x.ID).Count() }));

//var rowsEffected = ShopService.Instance.SaveOrder(newOrder);
