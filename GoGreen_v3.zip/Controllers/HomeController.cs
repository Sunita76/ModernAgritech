﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GoGreen.Models;
using GoGreen;
using GoGreen.Repository;
using System.Text;
using System.Web.Script.Serialization;
using System.Net;
using System.Net.Mail;

using System.Transactions;
using System.Threading.Tasks;

namespace GoGreen.Controllers
{
    public class State
    {
        public string name { get; set; }
    }


    public class HomeController : Controller
    {
        private IProducts _products = new ProductsList();  // the repository access
        private ICustomers _customer = new Customers();
        private IOrders _order = new Orders();

        public HomeController()
        {
            
          //  _products.StoreCacheProducts();

        }
        public ActionResult Contact()
        {
            return View();

        }
        public ActionResult About()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SendMail(Contacts model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    
                    var message = new MailMessage();
                 
                    message.Subject = model.Subject;
                    message.To.Add(new MailAddress("gogreen.group20@gmail.com"));  // send it to the emailid of gogreen.
                    //and also cc to the person of the from emailid. when sending the .pdf file.
                    // create another gmail account like webrequests@gmail.com for gogreen also.
                    if (model.FromEmail != null)
                    {
                       var body = "<p>Email From: {0} ({1})</p><p><b>Message:</b></p><p>{2}</p><p>Phone Number :{3}</p>";
                       message.From = new MailAddress(model.FromEmail);  // The mail will always be always be from modernagritech.webrequests@gmail.com , the from email is just to get the info in the message.
                       message.Body = string.Format(body, model.FromName, model.FromEmail, model.Message, model.PhoneNumber);
                    }
                    else
                    {
                        var body = "<p>Email From: {0} </p><p><b>Message:</b></p><p>{1}</p><p>Phone Number :{2}</p>";
                        message.From = new MailAddress("modernagritech.webrequests@gmail.com");
                        message.Body = string.Format(body, model.FromName, model.Message, model.PhoneNumber);
                    }
                    message.IsBodyHtml = true;

                    using (var smtp = new SmtpClient())
                    {
                        var credential = new NetworkCredential
                        {
                            UserName = "modernagritech.webrequests@gmail.com",  // replace with valid value
                            Password = "agritech@123"
                        };

                        smtp.Host = "smtp.gmail.com";
                        smtp.Port = 587;
                        smtp.EnableSsl = true;
                        smtp.UseDefaultCredentials = false;
                        smtp.Credentials = credential; // if google blocks the sign in attempt message, then in the gmail account settings, 
                        //Security->allow access to less secure apps.
                        smtp.Send(message);

                    }
                }
                return RedirectToAction("Index");


            }
            catch (Exception e)
            {
                Response.Write(e.Message);

            }
            return RedirectToAction("Index");
        }



        public ActionResult Index()
        {
            ProductsModel productslist = new ProductsModel();

            productslist.Products = _products.GetAllProducts();
            productslist.CalledFromCategory = "All"; //to denote by default All Products to be used after adding to cart.
            return View(productslist);


        }

        public ActionResult CategoryWise(string categorycalledfrom)
        {
            ProductsModel productslist = new ProductsModel();
            if (categorycalledfrom == "All")
            {
                productslist.Products = _products.GetAllProducts();
            
            }
            else
            {
                productslist.Products = _products.GetCategoryWiseProducts(categorycalledfrom);

            }
            productslist.CalledFromCategory = categorycalledfrom;
            TempData["current"] = "Products";
            TempData.Keep("current");
            return View("CategoryWise", productslist);
            
        }



        [HttpPost]
       public ActionResult AddtoCart(int id, string pack)
       {
          List<ShoppingCartModel> cartproducts = new List<ShoppingCartModel>();
            CartProductModel product = new CartProductModel();               
            Product productbyid = _products.GetProductById(id);      
            
            product.Name = productbyid.ProductName;
            product.ImageUrl = productbyid.ImageUrl;
            product.ID = productbyid.ProductId;
            product.ProductCategory = productbyid.Category;   
            product.Pack = pack;                                              
            product.PriceProduct = _products.GetPriceForPackAndProduct(id, pack).Price;

            if (Session["cart"] == null)   // session cart is empty.
            {
                cartproducts.Add(new ShoppingCartModel

                {
                    CartProduct = product,
                    Quantity = 1,
                    TotalPrice = product.PriceProduct
                });
                Session["cart"] = cartproducts;   //add a new ShoppingCartModel
                Session["count"] = 1;
            }
            else
            {
                cartproducts = (List<ShoppingCartModel>)Session["cart"];
                var count = cartproducts.Count();
                bool alreadythere = false;
                for (int i = 0; i < count; i++)
                {
                    if (cartproducts[i].CartProduct.ID == id)      //If the product is already there in the cart, increase the quantity.

                    {

                        cartproducts[i].Quantity = cartproducts[i].Quantity + 1;
                        cartproducts[i].TotalPrice = cartproducts[i].Quantity * cartproducts[i].CartProduct.PriceProduct;
                        alreadythere = true;
                        break;
                    }

                }

                if (alreadythere == false)
                {
                    cartproducts.Add(new ShoppingCartModel()
                    {
                        CartProduct = product,
                        Quantity = 1,
                        TotalPrice = product.PriceProduct
                    });

                }
                Session["cart"] = cartproducts;
                Session["count"] = Convert.ToInt32(Session["count"]) + 1;
            }

            TempData["current"] = "Products";
            TempData.Keep("current");
            var scount = Session["count"];
            var result = new { success = "Yes", count = scount };
           
            return Json(result, JsonRequestBehavior.AllowGet);
          


        }

        [HttpPost]
            public JsonResult ChangeProductPackPrice(int id,string pack)
             {
            Product_Price productprice = new Product_Price();
            productprice = _products.GetPriceForPackAndProduct(id, pack);
            
            return Json(productprice.Price, JsonRequestBehavior.AllowGet);
             
             }


        [HttpPost]
        public JsonResult ChangeProductQuantity(int id, int quantity)
        {

            List<ShoppingCartModel> cartproducts = (List<ShoppingCartModel>)Session["cart"];
            var count = cartproducts.Count(); // 1  2 first product
                                              // 3  3 second product
            for (int i = 0; i < count; i++)
            {
                if (cartproducts[i].CartProduct.ID == id)
                {
                    cartproducts[i].Quantity = quantity;
                    cartproducts[i].TotalPrice = quantity * cartproducts[i].CartProduct.PriceProduct;
                    break;
                }

            }
            int totalquantity = 0;
            for (int i = 0; i < count; i++)
            {
                totalquantity = totalquantity + cartproducts[i].Quantity;


            }
            Session["cart"] = cartproducts;
            Session["count"] = totalquantity;

            return Json(Convert.ToInt32(Session["count"]), JsonRequestBehavior.AllowGet);

        }


        public ActionResult ShoppingCart()
        {
            List<SelectListItem> Quantities = new List<SelectListItem>();

          
            for (var i = 1; i <= 20; i++)
                Quantities.Add(new SelectListItem { Text = i.ToString(), Value = i.ToString() });
            //{

            //new SelectListItem {Text = "1", Value = "1"},
            //new SelectListItem {Text = "2", Value = "2"},
            //new SelectListItem {Text = "3", Value = "3"},
            //new SelectListItem {Text = "4", Value = "4"},
            //new SelectListItem {Text = "5", Value = "5"},
            //new SelectListItem {Text = "6", Value = "6"},
            //new SelectListItem {Text = "7", Value = "7"},
            //new SelectListItem {Text = "8", Value = "8"},
            //new SelectListItem {Text = "9", Value = "9"},
            //new SelectListItem {Text = "10", Value = "10"},
            //new SelectListItem {Text = "11", Value = "11"},
            //new SelectListItem {Text = "12", Value = "12"},
            //new SelectListItem {Text = "13", Value = "13"},
            //new SelectListItem {Text = "14", Value = "14"},
            //new SelectListItem {Text = "15", Value = "15"},
            //new SelectListItem {Text = "16", Value = "16"},
            //new SelectListItem {Text = "17", Value = "17"},
            //new SelectListItem {Text = "18", Value = "18"},
            //new SelectListItem {Text = "19", Value = "19"},
            //new SelectListItem {Text = "20", Value = "20"}


            //};
            ViewData["Quantities"] = Quantities;

            return View("ShoppingCart", (List<ShoppingCartModel>)Session["cart"]);
            // to display the pack sizes and change the price according to the pack size selected.

        }


        public ActionResult RemoveItemfromCart(int id)  //delete the whole item.
        {
            List<ShoppingCartModel> shoppingcart = (List<ShoppingCartModel>)Session["cart"];

            float? quantityofitems = 0;
            foreach (var item in shoppingcart)
            {
                if (item.CartProduct.ID == id)
                {
                    quantityofitems = item.Quantity;  // the total quantity of that product.
                    break;
                }
            }

            shoppingcart.RemoveAll(x => x.CartProduct.ID == id);
            Session["cart"] = shoppingcart;

            Session["count"] = Convert.ToInt32(Session["count"]) - quantityofitems; // should decrease by the quantity of that product.


            return RedirectToAction("ShoppingCart");


        }
        [HttpGet]
        public ActionResult Checkout()
        {
            List<ShoppingCartModel> cartproducts = new List<ShoppingCartModel>();
            CustomerAndOrderViewModel model = new CustomerAndOrderViewModel();

            if (Session["cart"] != null)
            {
                cartproducts = (List<ShoppingCartModel>)Session["cart"];
                double? totalprice = 0;
                foreach (var product in cartproducts)
                {
                    totalprice = totalprice + product.TotalPrice;
                }
                ViewData["totalprice"] = totalprice;
                model.CartItems = cartproducts;
            }

            return View("Checkout", model);

        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Checkout(CustomerAndOrderViewModel model)
        {
            var created = false;
            try
            {
                string CustomerId = "";
                Customer customerlist = _customer.GetCustomerId((model.FirstName).Trim() + (model.LastName).Trim());
                if (customerlist != null)  // if the customer is already existing.
                {
                    CustomerId = customerlist.CustomerId;
                    customerlist.CustomerName = model.FirstName + model.LastName;
                    customerlist.Emailid = model.Email;
                    customerlist.Phone = model.PhoneNumber;
                    customerlist.State = model.State;
                    customerlist.City = model.Town;
                    customerlist.Address = model.Address + model.PinCode;

                    _customer.UpdateCustomer(customerlist);
                    created = true;


                }
                else  // Add a new customer.
                {
                    int count = _customer.GetCount();
                    count = count + 1;
                    CustomerId = "C00" + count + DateTime.Now.Year;
                    Customer customer = new Customer();
                    customer.CustomerId = CustomerId;
                    customer.CustomerName = model.FirstName.Trim() + model.LastName.Trim();
                    customer.Emailid = model.Email;
                    customer.Phone = model.PhoneNumber;
                    customer.State = model.State;
                    customer.City = model.Town;
                    customer.Address = model.Address + model.PinCode;
                    created = _customer.AddCustomerDetails(customer);
                }
                //Adding to the order table.
                List<ShoppingCartModel> cartitems = (List<ShoppingCartModel>)Session["cart"];
                OrderHeader order = new OrderHeader();
                order.OrderDate = DateTime.Now;
                order.CustomerId = CustomerId;
                List<OrderDetail> products = new List<OrderDetail>();
                foreach (var product in cartitems)
                {
                    OrderDetail detail = new OrderDetail();
                    detail.ProductId = product.CartProduct.ID;
                    detail.Quantity = product.Quantity;
                    products.Add(detail);


                }
                order.OrderDetails = products;
                created = _order.AddOrderHeader(order);


                StringBuilder textproducts = new StringBuilder("<p>Customer Name: " + model.FirstName + " " + model.LastName + "</p>");
                textproducts.Append("<p> Phone: " + model.PhoneNumber + "</p>");
                textproducts.Append("<table style='border:1px solid #ddd'><thead><tr style='border:1px solid #ddd'><th style='border: 1px solid #ddd'>ProductName</th><th style='border: 1px solid #ddd'>Unit Price(INR)</th><th style='border: 1px solid #ddd'>Quantity</th><th style='border: 1px solid #ddd'>Total Price(INR)</tr></thead>");
                double? totalprice = 0;
                System.Globalization.CultureInfo Indian = new System.Globalization.CultureInfo("hi-IN");
                foreach (var prod in cartitems)
                {

                    textproducts.Append("<tr style='border:1px solid #ddd'><td style='white-space:pre'>" + prod.CartProduct.Name + prod.CartProduct.Pack + "</td><td>" + String.Format(Indian, "{0:N}", prod.CartProduct.PriceProduct) + "</td><td>" + prod.Quantity + "</td><td>" + String.Format(Indian, "{0:N}", prod.CartProduct.PriceProduct * prod.Quantity) + "</td>");
                    totalprice = totalprice + prod.Quantity * prod.CartProduct.PriceProduct;
                }

                textproducts.Append("<tr style='border:1px solid #ddd'><td></td><td></td><td>Total Price(INR) </td><td>" + String.Format(Indian, "{0:N}", totalprice) + "</td></table>");


                textproducts.Append("<p>Note: The courier and transport charges will be extra.</p>");
                textproducts.Append("<p>Thanks for shopping with us. We have received your order.<br/> We will revert back to your phone number/email id with order confirmation and payment details within 2 working days.</p>");
                var message = new MailMessage();
                message.To.Add(new MailAddress("gogreen.group20@gmail.com"));                // send it to the emailid of gogreen.
                                                                                             //and also cc to the person of the from emailid. when sending the .pdf file.
                                                                                             //create another gmail account like webrequests@gmail.com for gogreen also.
                message.CC.Add(new MailAddress(model.Email));
                message.From = new MailAddress("modernagritech.webrequests@gmail.com");   //The mail will always be sent from the authenticated mailid.The from Id is just embedded in the body of the message.
                message.Subject = "The Order Confirmation";
                message.Body = textproducts.ToString();
                message.IsBodyHtml = true;

                using (var smtp = new SmtpClient())
                {
                    var credential = new NetworkCredential
                    {
                        UserName = "modernagritech.webrequests@gmail.com",  // replace with valid value
                        Password = "agritech@123"
                    };
                    smtp.Host = "smtp.gmail.com";
                    smtp.Port = 587;
                    smtp.EnableSsl = true;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = credential; // if google blocks the sign in attempt message, then in the gmail account settings, 
                                                   //Security->allow access to less secure apps.
                    smtp.Send(message);
                }

                if (created == true)
                {
                    Session.Remove("cart");
                    Session.Remove("count");
                    ViewBag.error = false;
                    return View("Final");
                }
                else
                {
                    ViewBag.error = true;
                    return View("Final");
                }
            }
            catch (Exception e)
            {
                created = false;
                ViewBag.error = true;
                return View("Final");
            }




        }


        [HttpPost]
        public JsonResult GetStates()
        {
            //get the Json filepath  
            string file = Server.MapPath("~/Content/States.json");
            //deserialize JSON from file  
            string jsonfile = System.IO.File.ReadAllText(file);
            JavaScriptSerializer ser = new JavaScriptSerializer();
            var stateslist = ser.Deserialize<List<State>>(jsonfile);


            return Json(stateslist.ToList(), JsonRequestBehavior.AllowGet);


        }
        public ActionResult Final()
        {
            return View();
        }





    }
}

/*Both allow you to set the expiration time of your data in the cache, so I understood here , it works like this:

absoluteExpiration: The time that the inserted object expires and is removed from the cache independent of when the object is accessed.

Example:

string cacheData = "Seu dado";
Cache.Insert("AbsoluteCacheKey", cacheData, null, DateTime.Now.AddMinutes(1), System.Web.Caching.Cache.NoSlidingExpiration);
Your data will be removed from the cache after 1 minute.

slidingExpiration: The time the object will be removed from the cache if it has not been accessed.

Example:

string cacheData = "Seu dado";
Cache.Insert("SlidingExpiration", cacheData, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(1));
Your data will be removed from the cache after 1 minute, but if it is accessed with 30 seconds to expire, it will be waited another 1 minute before removing it.*/
